from typing import Literal

from pydantic import Field, field_validator
from ..settings import StrictModel


class EmptyParams(StrictModel):
    pass


class InventoryParams(StrictModel):
    name_contains: str = Field(default="", max_length=256)
    extension: str = Field(default="", max_length=32)
    min_size: int = Field(default=0, ge=0)
    max_size: int | None = Field(default=None, ge=0)
    limit: int = Field(default=500, ge=1, le=10000)


class SearchParams(StrictModel):
    keyword: str = Field(min_length=1, max_length=256)
    case_sensitive: bool = False
    encoding: Literal["auto", "utf-8", "utf-8-sig", "utf-16", "utf-16-le", "utf-16-be", "gb18030"] = "auto"
    limit: int = Field(default=200, ge=1, le=1000)


class MetadataParams(StrictModel):
    fields: list[str] = Field(default_factory=list, max_length=32)

    @field_validator("fields")
    @classmethod
    def valid_fields(cls, value):
        if any(len(x) > 100 or not x or any(ord(ch) < 32 for ch in x) for x in value):
            raise ValueError("无效元数据字段")
        return value


class SQLiteParams(StrictModel):
    sql: str | None = Field(default=None, min_length=1, max_length=4096)
    parameters: list[str | int | float | None] = Field(default_factory=list, max_length=128)
    limit: int = Field(default=200, ge=1, le=1000)


class ArchiveParams(StrictModel):
    action: Literal["list", "extract"] = "list"


class PcapParams(StrictModel):
    protocol: Literal["overview", "dns", "http", "tls"] = "overview"
    limit: int = Field(default=200, ge=1, le=1000)


class EvtxParams(StrictModel):
    event_ids: list[int] = Field(default_factory=list, max_length=64)
    keyword: str = Field(default="", max_length=256)
    limit: int = Field(default=200, ge=1, le=1000)

    @field_validator("event_ids")
    @classmethod
    def valid_ids(cls, value):
        if any(x < 0 or x > 65535 for x in value):
            raise ValueError("事件 ID 范围应为 0..65535")
        return value
