import json
import re

from ..evidence.store import write_json


def inline(value):
    text = str(value)
    text = re.sub(r"[\x00-\x1f\x7f]", lambda m: f"\\u{ord(m.group()):04x}", text)
    return "".join("\\" + ch if ch in "\\`*_{}[]()#+-.!|<>" else ch for ch in text)


def code_json(value):
    text = json.dumps(value, ensure_ascii=False, indent=2)
    fence = "`" * max(3, max((len(x) + 1 for x in re.findall(r"`+", text)), default=3))
    return f"{fence}json\n{text}\n{fence}"


def original_lineage(case, source):
    lineage = []
    visited = set()
    while source:
        if source.id in visited:
            raise ValueError("来源链形成循环")
        visited.add(source.id)
        lineage.append(source.model_dump())
        source = case.sources.get(source.parent_id)
    return lineage


def generate_report(case):
    for step in case.manifest["steps"]:
        if "result" not in step:
            step["result"] = {"status": "failed", "warnings": ["步骤未完成，可能被外部终止；结果未验证"],
                              "error": "操作记录不完整"}
            step["integrity"] = {"issues": ["完整性复核未完成"]}
            step.setdefault("evidence", [])
    evidence = [row for step in case.manifest["steps"] for row in step["evidence"]]
    lines = ["# 取证分析报告", "", f"案件：{inline(case.manifest['case_id'])}", "",
             f"题目：{inline(case.manifest['question'])}", "",
             f"状态：{inline(case.manifest['state'])}", "", "## 解题计划", ""]
    lines += [f"{i}. {inline(line)}" for i, line in enumerate(case.manifest.get("plan", []), 1)] or ["直接工具调用。"]
    lines += ["", "## 候选答案与工具事实", ""]
    if case.manifest.get("answers"):
        for answer in case.manifest["answers"]:
            lines += [f"- 引用 {inline(answer['evidence_id'])} 的字段 {inline(answer['field'])}：",
                      code_json(answer["value"])]
            if answer.get("interpretation"):
                lines += [f"  候选解释（需要人工核对）：{inline(answer['interpretation'])}"]
    else:
        lines += ["没有经引用校验的模型候选答案。下列内容为工具直接输出；不能据此自动确认复杂问题。"]
    lines += ["", "## 检材来源清单", "",
              code_json([{"id": source.id, "original_path": source.original_path,
                          "working_path": source.working_path, "sha256": source.sha256,
                          "parent_id": source.parent_id, "member": source.member,
                          "filesystem": source.filesystem} for source in case.sources.values()]),
              "", "## 证据与定位", ""]
    failed_steps = {step["id"] for step in case.manifest["steps"]
                    if step["result"]["status"] not in {"ok", "partial"} or step["integrity"]["issues"]}
    for row in evidence:
        source = case.sources[row["source_id"]]
        lines += [f"### {inline(row['id'])}", "",
                  f"来源：{inline(source.original_path or '派生文件，见来源链')}", "",
                  f"SHA256：{source.sha256 or '目录无单一文件哈希'}", "",
                  f"工作副本：{inline(source.working_path)}", "",
                  f"原始工具输出：{inline(row['raw_output_path'])}", "",
                  code_json({"locator": row["locator"], "data": row["data"]}), ""]
        if row["id"].split(":")[0] in failed_steps:
            lines += ["本条来自失败或完整性检查不通过的步骤，仅供诊断，不能支持答案。", ""]
        if source.parent_id:
            lines += ["来源链：", code_json(original_lineage(case, source)), ""]
    lines += ["## 操作记录", ""]
    for step in case.manifest["steps"]:
        lines += [f"### {inline(step['id'])}：{inline(step['request']['tool_id'])}", "",
                  code_json({key: step.get(key) for key in ("request", "started_utc", "finished_utc",
                                                           "worker_argv", "worker_exit_code", "runtime_versions", "integrity")}), "",
                  f"状态：{inline(step['result']['status'])}", ""]
        command_file = case.directory / "steps" / step["id"] / "commands.jsonl"
        if command_file.is_file():
            commands = [json.loads(line) for line in command_file.read_text(encoding="utf-8").splitlines()]
            lines += [code_json(commands), ""]
    warnings = list(case.manifest["warnings"])
    for step in case.manifest["steps"]:
        warnings.extend(step["result"]["warnings"])
        if step["result"]["error"]:
            warnings.append(step["result"]["error"])
    lines += ["## 不确定性与限制", ""]
    lines += [f"- {inline(warning)}" for warning in dict.fromkeys(warnings)] or ["本次工具未报告额外警告；这不等于已穷尽全部取证方向。"]
    lines += ["", "所有时间字段保留工具原值；UTC 字段明确标注，缺少时区的元数据不自动转换。",
              "原始检材以只读方式读取，外部解析器使用工作副本；哈希检查验证内容，不保证访问时间等系统元数据不变。", ""]
    report_path = case.directory / "report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    write_json(case.directory / "report.json", {"case": case.manifest, "evidence": evidence,
                                                "warnings": list(dict.fromkeys(warnings))})
    return report_path
